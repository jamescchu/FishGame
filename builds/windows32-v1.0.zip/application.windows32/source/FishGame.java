import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Iterator; 
import shiffman.box2d.*; 
import org.jbox2d.common.*; 
import org.jbox2d.dynamics.joints.*; 
import org.jbox2d.collision.shapes.*; 
import org.jbox2d.collision.shapes.Shape; 
import org.jbox2d.common.*; 
import org.jbox2d.dynamics.*; 
import org.jbox2d.dynamics.contacts.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class FishGame extends PApplet {











Box2DProcessing box2d;
Fish fh;
Food fd;
Debug db;
MoverPlayer mp;
EventHandler eh;
Gui gui;

PFont fontL;
PFont fontS;
int currentMode = 1;
boolean debug = false, click = false, pressed = false;
int guiZone = 48;

public void setup() {
  //size(1280, 768, P2D); 
  
  noStroke();
  fontL = createFont("Helvetica", 100);
  fontS = createFont("Helvetica", 20);
  textFont(fontL);

  // Initialize Box2D
  box2d = new Box2DProcessing(this);
  box2d.createWorld();
  box2d.setGravity(0, 0);

  box2d.listenForCollisions();

  fh = new Fish();
  fd = new Food();
  db = new Debug();
  mp = new MoverPlayer();
  eh = new EventHandler();
  gui = new Gui();
}

public void draw() {
  background(0xff282927);

  // Step forward in time
  box2d.step();

  mp.run();
  eh.run();

  fd.run();
  fh.run();

  gui.display();

  if (debug) db.display();
}

public void keyPressed ()
{
  if (key == 'l') {
    debug = !debug;
  }
  if (debug) {
    if (key == 'k') {
      eh.foodEaten += 5;
    } else if (key == 'o') {
      db.debugEndGame();
    } else if (key == 'p') {
      db.debugSpawnEnemy();
    } else if (key == 'i') {
      eh.incoming = 360;
    }
  }
  mp.pressed();
}

public void keyReleased ()
{
  mp.released();
}

public void mouseClicked() {
  if (!eh.gameStart) { 
    eh.startGame();
    return;
  }
  if ((eh.gameOver && eh.waitTimer >= eh.waitAmount) || 
    (eh.gameWin && eh.waitTimer >= eh.waitAmount * 2)) { 
    eh.startGame();
    eh.gameOver = false;
    return;
  } else if (eh.gameOver) return;
  for ( Fish f : fh.fishes) {
    f.clicked();
  }
  for (int i = 0; i < gui.buttons.length; i++) {
    if (gui.buttons[i].isPressed()) {
      gui.buttons[i].click(i);
    }
  }
}

public void mousePressed() {
  pressed = true;
}

public void mouseReleased() {
  pressed = false;
}

public void beginContact(Contact cp) {
  // Get both fixtures
  Fixture f1 = cp.getFixtureA();
  Fixture f2 = cp.getFixtureB();
  // Get both bodies
  Body b1 = f1.getBody();
  Body b2 = f2.getBody();

  // Get our objects that reference these bodies
  Object o1 = b1.getUserData();
  Object o2 = b2.getUserData();

  if (o1.getClass() == FishPlayer.class && o2.getClass() == FoodSmall.class) {
    Fish p1 = (FishPlayer) o1;
    Food p2 = (FoodSmall) o2;
    p1.ate();
    p2.eaten();
  }

  if (o1.getClass() == FishPlayer.class && o2.getClass() == FishEnemy.class) {
    Fish p1 = (FishPlayer) o1;
    p1.lost();
  }
}

public void endContact(Contact cp) {
}

class Debug {
  Debug() {
  }

  public void drawWanderDebug(Vec2 _location, Vec2 _circle, Vec2 _target, float rad) {
    Vec2 location = box2d.coordWorldToPixels(_location);
    Vec2 circle = box2d.coordWorldToPixels(_circle);
    Vec2 target = box2d.coordWorldToPixels(_target);
    stroke(255);
    noFill();
    ellipseMode(CENTER);
    ellipse(circle.x, circle.y, rad * 2, rad * 2);
    ellipse(target.x, target.y, 4, 4);
    line(location.x, location.y, circle.x, circle.y);
    line(circle.x, circle.y, target.x, target.y);
  }

  public void drawMover() {
    PVector location = mp.getMover();
    fill(255);
    ellipseMode(CENTER);
    ellipse(location.x, location.y, 10, 10);
  }

  public void drawFishDebug(Body body, float size) {
    Vec2 pos = box2d.getBodyPixelCoord(body);
    // Get its angle of rotation
    float a = body.getAngle();
    pushMatrix();
    translate(pos.x, pos.y);
    rotate(a);
    fill(255);
    ellipse(0, 0, size, size);
    stroke(255);
    strokeWeight(1);
    // Let's add a line so we can see the rotation
    line(0, 0, size, 0);
    popMatrix();
  }

  public void display() {
    drawMover();
    fill(255);
    textSize(14);
    textAlign(BOTTOM, BOTTOM);
    text("FPS: " + frameRate, 10, 68);
    text("Objects: " + (fh.fishes.size() + fd.foods.size()), 10, 88);
    text("Size: " + sizeValue[sizeLevel], 10, 108);
    text("Speed: " + speedValue[speedLevel], 10, 128);
    text("Agile: " + agileValue[agileLevel], 10, 148);
    text("Damage: " + dmgValue[dmgLevel], 10, 168);
    text("SpawnRate: " + spawnValue[spawnLevel], 10, 188);
    text("EnemyHP: " + hpEnemyValue[eh.wave], 10, 208);
    text("IncomingTimer: " + eh.incoming, 10, 228);
  }
  
  public void debugEndGame() {
    eh.gameOver = true;
  }
  
  public void debugSpawnEnemy() {
    eh.spawnEnemy();
  }
}
class EventHandler extends Gui {
  int incoming;
  int wave;
  int waitTimer, waitAmount = 180;
  int waitWinTimer;
  boolean gameStart = false, gameOver = false, gameWin = false;

  int foodEaten = 0;

  EventHandler() {
    spawnLevel = 5;
  }

  public void run() {
    if (random(spawnValue[spawnLevel]) < 0.5f) {
      fd.spawnFood(random(width), random(height));
    }
    if (!eh.gameStart) return;
    if (incoming <= 0 && eh.wave != 6) {
      eh.wave++;

      spawnEnemy();

      int timer = 3600;
      if (eh.wave >= 4) timer = 2700;
      incoming = timer;
    }
    if (eh.wave >= 6) { 
      eh.wave = 6;
      incoming = 0;
      eh.waitWinTimer++;
    } else incoming--;
    if (eh.waitWinTimer >= eh.waitAmount * 2)
      eh.gameWin = true;
  }

  public void spawnEnemy() {
    PVector spawn = new PVector(random(width), random(height));
    PVector victim = fh.fishes.get(0).getLoc(); // super unstable
    if (PVector.dist(spawn, victim) >= 300) {
      fh.spawnFishEnemy(spawn);
    } else
      spawnEnemy();
  }

  public void resetGame() {
    eh.gameOver = false;
    eh.gameWin = false;
    fd.foods.clear();
    fh.fishes.clear();
    fh.spawnFishPlayer();
    mp.reset();
    speedLevel = 0;
    sizeLevel = 0;
    agileLevel = 0;
    dmgLevel = 0;
    spawnLevel = 0;
    foodEaten = 0;
    waitTimer = 0;
    incoming = 3600;
    wave = 0;
  }

  public void startGame() {
    eh.gameStart = true; 
    resetGame();
  }

  public void hurt() {
    hpEnemyValue[wave] -= dmgValue[dmgLevel];
  }
}
class Fish {
  ArrayList < Fish > fishes = new ArrayList < Fish > ();

  Body body;
  Vec2 direction;
  Vec2 VecLocation;

  PVector[] location;
  boolean isDead = false;
  float fishSize;
  float speed;
  float speedvar;
  float noiseScale;
  float noiseStrength;
  float accStrength;
  float wandertheta;
  int fishLength;
  int randColor;

  // Define colors
  HashMap < String, Integer > colors = new HashMap < String, Integer > () {
    {
      put("red", color(0xffE83503));
      put("gold", color(0xffFFC321));
      put("goldOrange", color(0xffF2A71B));
      put("redOrange", color(0xffF23005));
      put("orange", color(0xffFF8D04));
      put("white", color(0xffFFFAB0));
    }
  };

  Fish() {
  }

  public void display() {
    if (debug) db.drawFishDebug(body, fishSize);
  }

  public void seek(Vec2 loc) {
    seek(loc, 0.1f);
  }

  public void seek(Vec2 loc, float strength) {
    Vec2 location = getVecHead();
    float angle = atan2(loc.y - location.y, loc.x - location.x);

    Vec2 force = new Vec2(cos(angle), sin(angle));
    force.mulLocal(accStrength * strength);

    direction.addLocal(force);
    direction.normalize();
  }

  public void steer(Vec2 loc) {
    steer(loc, 0.1f);
  }

  public void steer(Vec2 loc, float strength) {
    Vec2 location = getVecHead();

    float angle = atan2(loc.y - location.y, loc.x - location.x);

    Vec2 force = new Vec2(cos(angle), sin(angle));
    force.mulLocal(accStrength * strength);

    direction.addLocal(force);
    direction.normalize();
    ;

    float currentDistance = dist(loc.x, loc.y, location.x, location.y);

    // Slow down if it's close to target
    if (currentDistance < 5) {
      speed = map(currentDistance, 0, 5, 0, speedValue[speedLevel]);
    }
  }

  public void createNoise() {
    Vec2 location = getVecHead();

    float noiseVal = noise(location.x / noiseScale, location.y / noiseScale); // Create noise value
    noiseVal *= PI * noiseStrength;
    Vec2 acceleration = new Vec2(cos(noiseVal), sin(-noiseVal));
    acceleration.mulLocal(accStrength);
    direction.addLocal(acceleration);
    direction.normalize();
  }

  public void update() {
  }

  public void move() {
    Vec2 location = getVecHead();

    Vec2 velocity = direction.clone();
    velocity.mulLocal(speed);
    location.addLocal(velocity);

    applyForce(velocity); // Apply force to box2d body
    setHead(location); // Update fish head location
  }

  public void spawnFishPlayer() {
    fishes.add(new FishPlayer());
  }

  public void spawnFishEnemy(PVector spawn) {
    fishes.add(new FishEnemy(spawn));
  }

  public void run() {
    // Itterate through ArrayList
    Iterator < Fish > it = fishes.iterator();
    while (it.hasNext()) {
      Fish f = it.next();
      f.run();
      if (f.isDead) {
        it.remove();
      }
    }
  }

  public void mode(int type) {
  }

  public void checkEdges() {
    // Get location of fish in pixels
    Vec2 location = box2d.coordWorldToPixels(getVecHead());
    float size = getSize(); // Get size of fish head

    if (location.x - size > width) {
      location.x = width - size / 2;
      setVecHead(location); // Teleport to opposite side
    }
    if (location.x + size < 0) {
      location.x = size / 2;
      setVecHead(location);
    }
    if (location.y - size > height) {
      location.y = height - size / 2;
      setVecHead(location);
    }
    if (location.y + size < guiZone) {
      location.y = guiZone + size / 2;
      setVecHead(location);
    }
  }

  public void makeBody(float x, float y) {
    // Define the body and make it from the shape
    BodyDef bd = new BodyDef();
    bd.type = BodyType.DYNAMIC;
    bd.position = box2d.coordPixelsToWorld(x, y);

    // Define a Circle
    CircleShape cs = new CircleShape();
    cs.m_radius = box2d.scalarPixelsToWorld(fishSize / 2);

    // Define a fixture
    FixtureDef fd = new FixtureDef();
    fd.shape = cs;
    // Parameters that affect physics
    fd.density = 1;
    fd.friction = 0.3f;
    fd.restitution = 0.5f;

    body = box2d.world.createBody(bd);
    body.createFixture(fd);
  }

  // Utilities

  public Vec2 getVecHead() {
    return body.getWorldCenter();
  }

  public void setHead(Vec2 pos) {
    location[location.length - 1] = box2d.coordWorldToPixelsPVector(pos);

    updateBody();
  }

  public void setVecHead(Vec2 pos) {
    pos = box2d.coordPixelsToWorld(pos);
    body.setTransform(pos, body.getAngle());
  }

  public void applyForce(Vec2 v) {
    body.applyForce(v, body.getWorldCenter());
  }

  public void updateBody() {
    for (int i = 0; i < location.length - 1; i++) {
      location[i] = location[i + 1];
    }
  }

  public void setDead() {
    isDead = true;
  }

  public void clicked() {
  }

  public void ate() {
  }

  public void lost() {
  }

  public PVector getLoc() {
    return location[0].copy();
  }

  public float getSize() {
    return fishSize;
  }

  public float getFoodDistance() {
    float dis = 0;
    for (Food f : fd.foods) {
      Vec2 kL = box2d.coordWorldToPixels(getVecHead());
      Vec2 fL = box2d.coordWorldToPixels(f.getFood());

      dis = dist(kL.x, kL.y, fL.x, fL.y);
    }
    return dis;
  }
}
class FishEnemy extends Fish {

  FishEnemy(PVector spawn) {
    // Need to define size first
    fishSize = 30;

    // Create Box2d body
    makeBody(spawn.x, spawn.y);
    body.setUserData(this);

    randColor = colors.get("gold");

    float angle = random(TWO_PI);
    direction = new Vec2(cos(angle), sin(angle));
    speedvar = speed;
    noiseScale = 10;
    noiseStrength = random(-0.5f, -0.8f);
    accStrength = random(0.8f, 0.9f);

    fishLength = 22;

    location = new PVector[fishLength];

    // Duplicate body position to pvector
    Vec2 pos = box2d.getBodyPixelCoord(body);
    location[0] = new PVector(pos.x, pos.y);

    for (int i = 1; i < location.length; i++) {
      location[i] = location[0].copy();
    }
  }

  public void mode() {
    if (!eh.gameOver) {
      Vec2 location = fh.fishes.get(0).getVecHead();

      speed = speedEnemyValue[eh.wave];
      fishSize = sizeEnemyValue[eh.wave];
      body.getFixtureList().getShape().setRadius(box2d.scalarPixelsToWorld(fishSize / 2));
      seek(location, 0.3f);
    } else
      createNoise();
  }

  public void display() {
    for (int i = 0; i < location.length; i++) {
      float size = map(i, 0, location.length, 1, fishSize);
      int c = lerpColor(colors.get("red"), colors.get("orange"), 
        map(i, 0, location.length, 1, 0));

      noStroke();
      fill(c);
      ellipse(location[i].x, location[i].y, size, size);
    }
    super.display();
  }

  public void clicked() {
    float dis = dist(location[location.length-1].x, location[location.length-1].y, mouseX, mouseY);
    if (dis <= fishSize + 2) {
      eh.hurt();
      noStroke();
      fill(colors.get("white"));
      ellipse(mouseX, mouseY, 10, 10);
    }
  }

  public void ate() {
  }

  public void grow() {
  }

  public void run() {
    if (hpEnemyValue[eh.wave] <= 0) {
      setDead();
    }
    mode();
    update();
    move();
    display();
  }
}
class FishPlayer extends Fish {

  FishPlayer() {
    // Need to define size first
    fishSize = 20;

    speed = 0.35f;

    // Create Box2d body
    makeBody(width/2, height/2);
    body.setUserData(this);

    float angle = random(TWO_PI);
    direction = new Vec2(cos(angle), sin(angle));
    speedvar = speed;
    noiseScale = 10;
    noiseStrength = random(-1, -0.6f);
    accStrength = random(0.4f, 0.5f);

    fishLength = 25;

    location = new PVector[fishLength];

    // Duplicate body position to pvector
    Vec2 pos = box2d.getBodyPixelCoord(body);
    location[0] = new PVector(pos.x, pos.y);

    for (int i = 1; i < location.length; i++) {
      location[i] = location[0].copy();
    }
  }

  public void mode() {
    Vec2 location = box2d.coordPixelsToWorld(mp.getMover());

    speed = speedValue[speedLevel];
    fishSize = sizeValue[sizeLevel];
    body.getFixtureList().getShape().setRadius(box2d.scalarPixelsToWorld(fishSize / 2));
    float agile = agileValue[agileLevel];
    steer(location, agile);
  }

  public void display() {
    for (int i = 0; i < location.length; i++) {
      float size = map(i, 0, location.length, 1, fishSize);
      int c = lerpColor(colors.get("goldOrange"), colors.get("white"), 
        map(i, 0, location.length, 1, 0));

      noStroke();
      fill(c);
      ellipse(location[i].x, location[i].y, size, size);
    }
    super.display();
  }

  public void ate() {
    eh.foodEaten++;
  }

  public void lost() {
    setDead();
    eh.gameOver = true;
  }

  public void run() {
    mode();
    move();
    display();
    checkEdges();
  }

  public Vec2 getLocation() {
    return fh.getVecHead();
  }
}
class Food {
  ArrayList < Food > foods = new ArrayList < Food > ();

  Vec2 location;
  Body body;
  float foodSize;
  int spawnTimer;
  boolean isEaten;
  HashMap < String, Integer > colors = new HashMap < String, Integer > () {
    {
      put("orange", color(0xffE57345));
    }
  };

  Food(Vec2 loc) {
    location = loc.clone();
    isEaten = false;
  }

  Food() {
    this(new Vec2(0, 0));
    isEaten = false;
  }

  public void display() {
  }

  public void update() {
    spawnTimer++;
    if (spawnTimer > 550) {
      float r = random(5);
      if (r < 0.3f)
        dissolve();
    }
  }

  public void run() {
    // Iterate through ArrayList
    update();
    Iterator < Food > it = foods.iterator();
    while (it.hasNext()) {
      Food f = it.next();
      f.run();
      if (f.isEaten) {
        it.remove();
      }
    }
  }

  public void makeBody(float x, float y) {
    // Define the body and make it from the shape
    BodyDef bd = new BodyDef();
    bd.type = BodyType.DYNAMIC;
    bd.position = box2d.coordPixelsToWorld(x, y);

    // Define a Circle
    CircleShape cs = new CircleShape();
    cs.m_radius = box2d.scalarPixelsToWorld(foodSize / 2);

    // Define a fixture
    FixtureDef fd = new FixtureDef();
    fd.shape = cs;
    // Parameters that affect physics
    fd.density = 1;
    fd.friction = 0.3f;
    fd.restitution = 0.5f;

    body = box2d.world.createBody(bd);
    body.createFixture(fd);

    body.setLinearVelocity(new Vec2(random(-5, 5), random(2, 5)));
    body.setAngularVelocity(random(-3, 3));
  }

  public void spawnFood(float x, float y) {
    foods.add(new FoodSmall(new Vec2(x, y)));
  }

  public Vec2 getFood() {
    return body.getWorldCenter();
  }

  public void setVecFood(Vec2 pos) {
    pos = box2d.coordPixelsToWorld(pos);
    body.setTransform(pos, body.getAngle());
  }

  public void dissolve() {
    eaten();
  }

  public void eaten() {
    isEaten = true;
  }
}
class FoodSmall extends Food {

  FoodSmall(Vec2 loc) {
    super(loc);
    foodSize = random(6,9);

    makeBody(loc.x, loc.y);
    body.setUserData(this);
  }

  public void display() {

    Vec2 pos = box2d.getBodyPixelCoord(body);
    
    // Get its angle of rotation
    pushMatrix();
    translate(pos.x, pos.y);
    fill(colors.get("orange"));
    ellipse(0, 0, foodSize, foodSize);
    popMatrix();
  }

  public void run() {
    update();
    display();
  }
}
class Gui {
  GuiButton[] buttons = new GuiButton[5];
  HashMap < String, Integer > colors = new HashMap < String, Integer > () {
    {
      put("orange", color(0xffFF8D04));
      put("gold", color(0xffFFC321));
      put("gray", color(0xffC6C6C6));
      put("darkgray", color(0xff2D2D2D));
      put("white", color(0xffFFFFFF));
      put("red", color(0xffE83503));
    }
  };

  Gui() {
  }

  public void display() {
    if (!eh.gameStart && !eh.gameOver) {
      showInstructions();
    } else if (eh.gameOver) {
      showGameOver();
    } else if (eh.gameWin) {
      showGameWin();
    } else if (eh.gameStart) {
      drawGameUI();
    }
  }

  public void drawGameUI() {
    drawBase();
    showFoodCount();
    setUpgrades("SIZE LVL " + sizeLevel, sizeCost[sizeLevel], 20, 0);
    setUpgrades("SPEED LVL " + speedLevel, speedCost[speedLevel], 140, 1);
    setUpgrades("AGILITY LVL " + agileLevel, agileCost[agileLevel], 270, 2);
    setUpgrades("DAMAGE LVL " + dmgLevel, dmgCost[dmgLevel], 410, 3);
    setUpgrades("SPAWN RATE LVL " + spawnLevel, spawnCost[spawnLevel], 560, 4);
    for (int i = 0; i < buttons.length; i++) {
      buttons[i].affordable(i);
      buttons[i].update();
    }

    showTimer();
  }

  public void drawBase() {
    noStroke();
    rectMode(CENTER);
    fill(colors.get("orange"));
    rect(width/2, guiZone/2, width, guiZone);
  }

  public void showFoodCount() {
    textFont(fontS);
    drawRightString("FOOD POINTS: " + eh.foodEaten, width - 20, guiZone/2 - 1, colors.get("white"), 16);
  }

  public void showTimer() {
    if (!eh.gameStart) return;
    drawRightString("Predator Timer: " + eh.incoming/60, width - 180, guiZone/2 - 8, colors.get("red"), 16);
    drawRightString("WAVE: " + eh.wave, width - 180, guiZone/2 + 12, colors.get("white"), 12);
    if (eh.incoming <= 300 && eh.wave != 6)
      drawCenteredString("INCOMING " + eh.incoming/60, width/2, height/2 + 30, colors.get("red"), 20); 
  }

  public void setUpgrades(String _type, int _cost, int _xPos, int id) {
    String cost = "COST " + _cost;
    if (_cost >= 30)
      cost = "MAXED OUT";
    textFont(fontS);
    drawString(_type, _xPos, guiZone/2 - 8, colors.get("white"), 16); 
    drawString(cost, _xPos, guiZone/2 + 12, colors.get("white"), 12); 
    buttons[id] = new GuiButton(_xPos + textWidth(_type)*1.4f, guiZone/2 - 5);
  }

  public void showGameOver() { 
    eh.waitTimer++;
    noStroke();
    fill(0, 100);
    rectMode(CORNERS);
    rect(0, 0, width, height);
    textFont(fontL);
    drawCenteredString("GAME OVER", width/2, height/2, colors.get("red"), 100); 
    textFont(fontS);
    drawCenteredString("YOU MADE IT TO WAVE: " + eh.wave, width/2, height/2 + 30, colors.get("white"), 20); 
    if (eh.waitTimer >= eh.waitAmount)
      drawCenteredString("CLICK TO RESTART", width/2, height/2 + 250, colors.get("orange"), 16);
  }

  public void showGameWin() { 
    eh.waitTimer++;
    noStroke();
    fill(0, 100);
    rectMode(CORNERS);
    rect(0, 0, width, height);
    textFont(fontL);
    drawCenteredString("CONGRATULATIONS", width/2, height/2, colors.get("red"), 100); 
    textFont(fontS);
    drawCenteredString("YOU MADE IT PAST WAVE 5", width/2, height/2 + 30, colors.get("white"), 20); 
    if (eh.waitTimer >= eh.waitAmount)
      drawCenteredString("CLICK TO PLAY AGAIN", width/2, height/2 + 250, colors.get("orange"), 16);
  }

  public void showInstructions() { 
    fill(0, 100);
    noStroke();
    rectMode(CORNERS);
    rect(0, 0, width, height);
    textFont(fontL);
    drawCenteredString("FISH SURVIVAL", width/2, height/2, colors.get("gold"), 100); 
    textFont(fontS);
    drawCenteredString("CREATED BY JAMES CHU", width/2, height/2 + 30, colors.get("white"), 20); 
    drawCenteredString("INSTRUCTIONS:", width/2, height/2 + 80, colors.get("white"), 16); 
    drawCenteredString("CONTROL FISH WITH ARROW KEYS", width/2, height/2 + 100, colors.get("white"), 16); 
    drawCenteredString("EAT FOOD TO GAIN FOOD POINTS", width/2, height/2 + 120, colors.get("white"), 16); 
    drawCenteredString("USE FOOD POINTS TO LEVEL UP YOUR FISH", width/2, height/2 + 140, colors.get("white"), 16); 
    drawCenteredString("CLICK ON PREDATOR TO KILL IT", width/2, height/2 + 160, colors.get("white"), 16);
    drawCenteredString("CLICK TO START", width/2, height/2 + 250, colors.get("red"), 16);
  }

  // Utilities
  public void drawString(String _string, float _xPos, float _yPos, int _color, int size) {
    fill(_color);
    textAlign(LEFT, CENTER);
    textSize(size);
    text(_string, _xPos, _yPos);
  }

  public void drawRightString(String _string, float _xPos, float _yPos, int _color, int size) {
    fill(_color);
    textAlign(RIGHT, CENTER);
    textSize(size);
    text(_string, _xPos, _yPos);
  }

  public void drawButtonString(String _string, float _xPos, float _yPos, int _color) {
    fill(_color);
    textAlign(LEFT, TOP);
    textSize(20);
    text(_string, _xPos, _yPos);
  }

  public void drawCenteredString(String _string, float _xPos, float _yPos, int _color, int size) {
    fill(_color);
    textAlign(CENTER);
    textSize(size);
    text(_string, _xPos, _yPos);
  }
}
class GuiButton extends Gui {
  GuiButton[] buttons = new GuiButton[5];
  boolean enabled = true;
  float xPos, yPos;
  int size;

  final int mDefault = 0, mPressed = 1, mHover = 2, mDisabled = 3;

  GuiButton(float _xPos, float _yPos) {
    xPos = _xPos;
    yPos = _yPos-12;
    size = 25;
  }

  GuiButton() {
    this(0, 0);
  }

  public void drawButton(int action) {
    int textColor = colors.get("white");
    switch(action) {
    case mDefault:
      textColor = colors.get("white");
      break;
    case mPressed:
      textColor = colors.get("gray");
      break;
    case mHover:
      textColor = colors.get("red");
      break;
    case mDisabled:
      textColor = colors.get("darkgray");
      break;
    }

    drawButtonString("+", xPos, yPos, textColor);
  }

  public void affordable(int id) {
    switch(id) {
    case 0:
      if ( eh.foodEaten >= sizeCost[sizeLevel] && sizeLevel < 5) enabled = true;
      else if (sizeLevel >= 5)
        enabled = false;
      else enabled = false;
      break;
    case 1:
      if ( eh.foodEaten >=  speedCost[ speedLevel] &&  speedLevel < 5) enabled = true;
      else if ( speedLevel >= 5)
        enabled = false;
      else enabled = false;
      break;
    case 2:
      if ( eh.foodEaten >=  agileCost[ agileLevel] &&  agileLevel < 5) enabled = true;
      else if ( agileLevel >= 5)
        enabled = false;
      else enabled = false;
      break;
    case 3:
      if ( eh.foodEaten >=  dmgCost[ dmgLevel] &&  dmgLevel < 5) enabled = true;
      else enabled = false;
      break;
    case 4:
      if ( eh.foodEaten >=  spawnCost[ spawnLevel] &&  spawnLevel < 5) enabled = true;
      else enabled = false;
      break;
    }
  }

  public boolean isPressed() {
    if (mouseX > xPos && mouseX < xPos+size && mouseY >  yPos && mouseY < yPos+size && enabled) {
      return true;
    }
    return false;
  }

  public void click(int id) {
    if (mouseX > xPos && mouseX < xPos+size && mouseY >  yPos && mouseY < yPos+size && enabled) {
      switch(id) {
      case 0:
         eh.foodEaten -=  sizeCost[ sizeLevel];
         sizeLevel++;
        if ( sizeLevel > 5)  sizeLevel = 5;
        break;
      case 1:
         eh.foodEaten -=  speedCost[ speedLevel];
         speedLevel++;
        if ( speedLevel > 5)  speedLevel = 5;
        break;
      case 2:
         eh.foodEaten -=  agileCost[ agileLevel];
         agileLevel++;
        if ( agileLevel > 5)  agileLevel = 5;
        break;
      case 3:
         eh.foodEaten -=  dmgCost[ dmgLevel];
         dmgLevel++;
        if ( dmgLevel > 5)  dmgLevel = 5;
        break;
      case 4:
         eh.foodEaten -=  spawnCost[ spawnLevel];
         spawnLevel++;
        if ( spawnLevel > 5) spawnLevel = 5;
        break;
      }
    }
  }

  public void update() {
    if (mouseX > xPos && mouseX < xPos+size && mouseY >  yPos && mouseY < yPos+size && enabled) {
      if (pressed) {
        drawButton(mPressed);
      } else 
      drawButton(mHover);
    } else if (!enabled)
      drawButton(mDisabled);
    else {
      drawButton(mDefault);
    }
  }
}
int speedLevel = 0;
float[] speedValue = {
  0.20f, 0.28f, 0.36f, 0.44f, 0.52f, 0.6f
};
int[] speedCost = {
  5, 10, 15, 20, 25, 30
};

int sizeLevel = 0;
float[] sizeValue = {
  8, 12, 16, 18, 22, 26
};
int[] sizeCost = {
  5, 10, 15, 20, 25, 30
};

int agileLevel = 0;
float[] agileValue = {
  0.3f, 0.5f, 0.6f, 0.8f, 1.2f, 2
};
int[] agileCost = {
  5, 10, 15, 20, 25, 30
};

int dmgLevel = 0;
float[] dmgValue = {
  1, 2, 3, 4, 5, 6
};
int[] dmgCost = {
  5, 10, 15, 20, 25, 30
};

int spawnLevel = 0;
float[] spawnValue = {
  30, 27, 25, 21, 16, 10
};
int[] spawnCost = {
  5, 10, 15, 20, 25, 30
};

float[] speedEnemyValue = {
  0, 0.25f, 0.32f, 0.37f, 0.44f, 0.53f, 0.61f
};

float[] sizeEnemyValue = {
  0, 26, 24, 22, 20, 18, 15
};

float[] hpEnemyValue = {
  1, 6, 10, 12, 15, 19, 23
};
class MoverPlayer {

  // Use booleans to eliminate unreliable key triggers
  boolean right = false, left = false, up = false, down = false;
  float spd;
  float offset;

  PVector location;

  MoverPlayer() {
    location = new PVector(width/2, height/2);
  }

  public void pressed() {
    if (key == CODED) {
      if (keyCode == UP) {
        up = true;
      } else if (keyCode == DOWN) {
        down = true;
      } else if (keyCode == LEFT) {
        left = true;
      } else if (keyCode == RIGHT) {
        right = true;
      }
    }
  }

  public void released() {
    if (key == CODED) {
      if (keyCode == UP) {
        up = false;
      } else if (keyCode == DOWN) {
        down = false;
      } else if (keyCode == LEFT) {
        left = false;
      } else if (keyCode == RIGHT) {
        right = false;
      }
    }
  }

  public void update() {
    spd = speedValue[speedLevel] * 10;
    if (left) location.x -= spd;
    else if (right) location.x += spd;

    if (up) location.y -=spd;
    else if (down) location.y += spd;
  }

  public void run() {
    update();
    checkEdges();
  }
  
  public void reset() {
    location.set(width/2, height/2);
  }

  public void checkEdges() {
    PVector location = getMover();

    if (location.x > width) {
      location.x = width;
      setMover(location);
    }
    if (location.x < 0) {
      location.x = 0;
      setMover(location);
    }
    if (location.y > height) {
      location.y = height;
      setMover(location);
    }
    if (location.y < guiZone) {
      location.y = guiZone;
      setMover(location);
    }
  }

  public PVector getMover() {
    return location.copy();
  }

  public void setMover(PVector loc) {
    location = loc.copy();
  }
}
  public void settings() {  fullScreen(P2D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "FishGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
